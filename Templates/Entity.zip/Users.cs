using System;
using System.Collections.Generic;
using System.Text;
using Firefly.Box;
using ENV.Data;

namespace $rootnamespace$
{
    public class $safeitemname$ : Entity
    {
        
        public $safeitemname$()
            : base("$safeitemname$", dataSource)
        {
        }
        
    }
}
