using System.Drawing;
using Firefly.Box.UI;
using Firefly.Box;
using ENV;
using ENV.Data;

namespace $rootnamespace$
{
    
    /// <summary>$safeitemname$</summary>
    public partial class $safeitemname$ : Theme.Controls.TextBox
    {
        
        
        /// <summary>$safeitemname$</summary>
        public $safeitemname$()
        {
            InitializeComponent();
        }
       
    }
}
