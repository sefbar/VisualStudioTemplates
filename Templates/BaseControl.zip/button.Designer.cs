using System.Drawing;
using Firefly.Box.UI;
using Firefly.Box;
using ENV;
using ENV.Data;

namespace $rootnamespace$
{
    partial class $safeitemname$
    {
        void InitializeComponent()
        {
        }
    }
}
