using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using Firefly.Box;
using ENV;
using ENV.Data;

namespace $rootnamespace$
{
    public class $safeitemname$:BusinessProcessBase
    {
        // TODO: Add members Here

        public $safeitemname$()
        {
            //TODO: Add task definitions here
        }
        public void Run()
        {
            Execute();
        }
    }
}
