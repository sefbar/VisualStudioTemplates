using System;
using System.Collections.Generic;
using System.Text;
using Firefly.Box;
using ENV.Data;

namespace $rootnamespace$
{
    public class $safeitemname$:NumberColumn
    {
        public $safeitemname$(string name,string format,string caption):base(name,format,caption)
        {
        }
        public $safeitemname$(string name,string format):base(name,format)
        {
        }
        public $safeitemname$(string name):base(name)
        {
        }
        public $safeitemname$():base("$safeitemname$")
        {
        }
    }
}
