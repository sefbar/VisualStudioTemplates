using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Firefly.Box;
using ENV;
using ENV.Data;

namespace $rootnamespace$
{
    partial class $safeitemname$ : Theme.Printing.ReportLayout
    {

        public $safeitemname$()
        {
            InitializeComponent();
        }
    }
}